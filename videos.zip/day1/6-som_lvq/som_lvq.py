import numpy as np

# 1. KOHONEN SELF ORGANIZING MAP (SOM)
print("KOHONEN SELF ORGANIZING MAP")

# Input data (unlabelled)
X = np.array([
    [0.2, 0.3],
    [0.25, 0.35],
    [0.8, 0.9],
    [0.75, 0.85]
])

# Two neurons with random weights
weights = np.array([
    [0.1, 0.2],
    [0.9, 0.8]
])

learning_rate = 0.5

# Training
for epoch in range(5):
    for x in X:
        # Calculate distance from neurons
        distance = np.linalg.norm(weights - x, axis=1)
        # Winner neuron (BMU)
        winner = np.argmin(distance)
        # Update winner weight
        weights[winner] = weights[winner] + learning_rate * (x - weights[winner])

    print("Epoch", epoch+1)
    print(weights)

# Testing SOM
print("\nFinal SOM Weights:")
print(weights)

for x in X:
    distance = np.linalg.norm(weights - x, axis=1)
    winner = np.argmin(distance)
    print("Input:", x, "belongs to Neuron:", winner)

# 2. LEARNING VECTOR QUANTIZATION (LVQ)
print("\n\nLEARNING VECTOR QUANTIZATION")

# Training data with classes
X = np.array([
    [1,1],
    [1.5,1.2],
    [5,5],
    [5.5,5.2]
])

# Class labels
Y = np.array([0,0,1,1])

# Initial prototype vectors
weights = np.array([
    [1,1],
    [5,5]
])

# Class of prototype neurons
classes = np.array([0,1])
learning_rate = 0.3

# Training
for epoch in range(5):
    for i in range(len(X)):
        x = X[i]
        target = Y[i]
        # Find closest neuron
        distance = np.linalg.norm(weights-x,axis=1)
        winner = np.argmin(distance)

        # Correct class
        if classes[winner] == target:
            # Move weight closer
            weights[winner] = weights[winner] + learning_rate*(x-weights[winner])
        else:
            # Move weight away
            weights[winner] = weights[winner] - learning_rate*(x-weights[winner])

    print("\nEpoch",epoch+1)
    print(weights)

# Testing LVQ
print("\nFinal LVQ Weights:")
print(weights)

test = np.array([1.2,1.1])
distance = np.linalg.norm(weights-test,axis=1)
winner = np.argmin(distance)
print("\nTest Input:",test)
print("Predicted Class:",classes[winner])