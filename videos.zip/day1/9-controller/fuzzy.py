setpoint = 24
current_temp = 18
previous_error = 5

error = setpoint - current_temp
change = error - previous_error

def negative(x, limit):
    return max(0, min(1, -x/limit))

def zero(x, limit):
    return max(0, 1 - abs(x)/limit)

def positive(x, limit):
    return max(0, min(1, x/limit))

# Fuzzification
eN = negative(error, 10)
eZ = zero(error, 10)
eP = positive(error, 10)

dN = negative(change, 5)
dZ = zero(change, 5)
dP = positive(change, 5)

# Rule evaluation
low = max(min(eN,dN), min(eN,dZ),
          min(eN,dP), min(eZ,dN))

medium = max(min(eZ,dZ), min(eP,dN))

high = max(min(eZ,dP), min(eP,dZ),
           min(eP,dP))

# Defuzzification
num = 0
den = 0

for p in range(101):
    l = max(0, (50-p)/50)
    m = max(0, min(p/50, (100-p)/50))
    h = max(0, (p-50)/50)

    output = max(min(low,l), min(medium,m), min(high,h))

    num += p * output
    den += output

power = num / den

print("Error:", error)
print("Change:", change)
print("Low:", round(low,2))
print("Medium:", round(medium,2))
print("High:", round(high,2))
print("Heater Power:", round(power,2), "%")