import numpy as np

# Training data: PM2.5, PM10, AQI
data = np.array([
    [10,30,35], [20,55,55], [30,65,70], [40,100,95],
    [50,105,115], [60,140,135], [70,145,155], [80,180,180],
    [90,185,200], [100,220,220], [110,225,240],
    [120,260,260], [130,265,280], [140,300,305],
    [150,305,325], [160,340,350]
])

X = data[:, :2]
y = data[:, 2]

# Gaussian membership function
def gaussian(x, mean, sigma):
    return np.exp(-((x-mean)**2)/(2*sigma**2))

# Calculate rule weights
def get_weights(a, b):
    x = [gaussian(a,30,35), gaussian(a,120,70)]
    y = [gaussian(b,60,60), gaussian(b,250,130)]

    w = [x[0]*y[0], x[0]*y[1],
         x[1]*y[0], x[1]*y[1]]

    total = sum(w)
    return [i/total for i in w]

# Create training features
features = []

for a, b in X:
    weights = get_weights(a, b)
    row = []

    for w in weights:
        row.extend([w*a, w*b, w])

    features.append(row)

features = np.array(features)

# Train ANFIS
p = np.linalg.lstsq(features, y, rcond=None)[0]

print("ANFIS Training Completed!")

# Predict AQI
pm25 = 80
pm10 = 180

weights = get_weights(pm25, pm10)
row = []

for w in weights:
    row.extend([w*pm25, w*pm10, w])

result = np.dot(row, p)

print("PM2.5:", pm25)
print("PM10:", pm10)
print("Predicted AQI:", round(result, 2))