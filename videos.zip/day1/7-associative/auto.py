pattern = [1, -1, 1, -1, 1]
noisy_input = [-1, -1, 1, -1, 1]

n = len(pattern)

W = [[0 for j in range(n)] for i in range(n)]

# Create weight matrix
for i in range(n):
    for j in range(n):
        if i != j:
            W[i][j] = pattern[i] * pattern[j]

# Recall pattern
result = []

for i in range(n):
    net = 0

    for j in range(n):
        net += W[i][j] * noisy_input[j]

    result.append(1 if net >= 0 else -1)

print("Original Pattern:", pattern)
print("Noisy Input:", noisy_input)
print("Recalled Pattern:", result)