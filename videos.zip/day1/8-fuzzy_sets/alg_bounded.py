A = [0.2, 0.3, 0.4, 0.5]
B = [0.1, 0.2, 0.2, 1.0]

algebraic_sum = []
algebraic_product = []
bounded_sum = []
bounded_difference = []

for i in range(len(A)):
    a = A[i]
    b = B[i]

    algebraic_sum.append(round(a+b-a*b, 2))
    algebraic_product.append(round(a*b, 2))
    bounded_sum.append(round(min(1, a+b), 2))
    bounded_difference.append(round(max(0, a-b), 2))

print("A =", A)
print("B =", B)
print("Algebraic Sum =", algebraic_sum)
print("Algebraic Product =", algebraic_product)
print("Bounded Sum =", bounded_sum)
print("Bounded Difference =", bounded_difference)