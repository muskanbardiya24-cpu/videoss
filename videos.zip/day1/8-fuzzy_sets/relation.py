R = [
    [0.6, 0.3],
    [0.2, 0.9]
]

S = [
    [1.0, 0.5, 0.3],
    [0.8, 0.4, 0.7]
]

# Max-Min Composition
max_min = []

for i in range(len(R)):
    row = []

    for j in range(len(S[0])):
        values = []

        for k in range(len(S)):
            values.append(min(R[i][k], S[k][j]))

        row.append(max(values))

    max_min.append(row)

# Max-Product Composition
max_product = []

for i in range(len(R)):
    row = []

    for j in range(len(S[0])):
        values = []

        for k in range(len(S)):
            values.append(R[i][k] * S[k][j])

        row.append(round(max(values), 2))

    max_product.append(row)

print("Max-Min Composition:")
for row in max_min:
    print(row)

print("Max-Product Composition:")
for row in max_product:
    print(row)