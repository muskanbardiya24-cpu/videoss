def dfs():
    stack = [(0, 0)]
    visited = [(0, 0)]
    parent = {(0, 0): None}

    while stack:
        a, b = stack.pop()

        if a == 2 or b == 2:
            path = []
            state = (a, b)

            while state is not None:
                path.append(state)
                state = parent[state]

            print("DFS Solution:")
            for x in path[::-1]:
                print(x)
            return

        states = [
            (4, b), (a, 3),
            (0, b), (a, 0),
            (a-min(a, 3-b), b+min(a, 3-b)),
            (a+min(b, 4-a), b-min(b, 4-a))
        ]

        for s in states:
            if s not in visited:
                visited.append(s)
                parent[s] = (a, b)
                stack.append(s)

dfs()