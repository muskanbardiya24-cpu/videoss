# Half Adder using McCulloch-Pitts Neuron
def neuron(inputs, weights, threshold):
    weighted_sum = 0
    for i in range(len(inputs)):
        weighted_sum += inputs[i] * weights[i]
    if weighted_sum >= threshold:
        return 1
    else:
        return 0

# Logic Gates using M-P Neuron
def AND(a, b):
    return neuron([a, b], [1, 1], 2)

def OR(a, b):
    return neuron([a, b], [1, 1], 1)

def NAND(a, b):
    return neuron([a, b], [-1, -1], -1)

# XOR using NAND, AND and OR
def XOR(a, b):
    n = NAND(a, b)
    p = AND(a, n)
    q = AND(b, n)
    return OR(p, q)

# Half Adder Implementation
print("HALF ADDER USING McCULLOCH-PITTS NEURON")
print("--------------------------------------")
print("A  B | SUM  CARRY")
print("--------------------------------------")

for A in [0, 1]:
    for B in [0, 1]:
        SUM = XOR(A, B)
        CARRY = AND(A, B)
        print(A, " ", B, " |  ", SUM, "     ", CARRY)