# Backpropagation: House Price
# Ubuntu: python3 house_price.py
# Dependencies: Python 3 standard library only (no internet needed).

import math
import random
random.seed(3)
# Tiny synthetic dataset: educational demonstration, not a production prediction.
X = [
    [600, 1, 15],
    [900, 2, 12],
    [1200, 2, 8],
    [1500, 3, 10],
    [1700, 3, 5],
    [2000, 4, 4],
    [2400, 4, 2],
    [2700, 5, 1],
]
Y = [0.15, 0.24, 0.35, 0.43, 0.53, 0.68, 0.82, 0.95]

# Normalize each input feature to 0..1.
low = [min(row[j] for row in X) for j in range(len(X[0]))]
high = [max(row[j] for row in X) for j in range(len(X[0]))]
def normalize(row):
    return [(x-a)/(b-a) if b != a else 0.0
            for x,a,b in zip(row,low,high)]

def sigmoid(z):
    return 1/(1+math.exp(-max(-60,min(60,z))))

n = len(X[0]); hidden = 4
w1 = [[random.uniform(-0.5,0.5) for _ in range(n)] for _ in range(hidden)]
b1 = [0.0]*hidden
w2 = [random.uniform(-0.5,0.5) for _ in range(hidden)]
b2 = 0.0
rate = 0.5
for epoch in range(1000):
    for raw,target in zip(X,Y):
        x = normalize(raw)
        h = [sigmoid(sum(a*b for a,b in zip(weights,x)) + bias)
             for weights,bias in zip(w1,b1)]
        output = sigmoid(sum(a*b for a,b in zip(w2,h)) + b2)
        delta_out = (target-output)*output*(1-output)
        delta_h = [delta_out*w2[j]*h[j]*(1-h[j]) for j in range(hidden)]
        for j in range(hidden):
            w2[j] += rate*delta_out*h[j]
        b2 += rate*delta_out
        for j in range(hidden):
            for k in range(n):
                w1[j][k] += rate*delta_h[j]*x[k]
            b1[j] += rate*delta_h[j]

def predict(raw):
    x = normalize(raw)
    h = [sigmoid(sum(a*b for a,b in zip(weights,x))+bias)
         for weights,bias in zip(w1,b1)]
    return sigmoid(sum(a*b for a,b in zip(w2,h)) + b2)

print('Experiment:', 'house_price')
print('Input features:', 'sqft, bedrooms, age years')
test = [1600, 3, 6]
score = predict(test)
print('Predicted value:', round(score*500000, 2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Experiment: house_price
# OUTPUT: Input features: sqft, bedrooms, age years
# OUTPUT: Predicted value: 262265.42
