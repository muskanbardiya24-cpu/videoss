# Learning Vector Quantization
# Ubuntu: python3 lvq.py
# Dependencies: Python 3 standard library only (no internet needed).

# Learning Vector Quantization with two labeled prototypes.
import math
X = [(0.1,0.2),(0.2,0.3),(0.8,0.9),(0.9,0.8)]
labels = [0,0,1,1]
weights = [[0.15,0.1],[0.85,0.75]]
prototype_labels = [0,1]
rate = 0.2
for epoch in range(20):
    for x,label in zip(X,labels):
        i = min(range(2), key=lambda j:math.dist(weights[j], x))
        sign = 1 if prototype_labels[i] == label else -1
        weights[i] = [w+sign*rate*(v-w) for w,v in zip(weights[i],x)]
print('Trained prototypes:', [[round(v,3) for v in w] for w in weights])
for x in [(0.1,0.25),(0.85,0.88)]:
    i = min(range(2),key=lambda j:math.dist(weights[j],x))
    print(x,'-> class',prototype_labels[i])

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Trained prototypes: [[0.156, 0.256], [0.856, 0.844]]
# OUTPUT: (0.1, 0.25) -> class 0
# OUTPUT: (0.85, 0.88) -> class 1
