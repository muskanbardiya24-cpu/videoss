# Fuzzy AQI and Health Effects - Case Study from Lab PDF
# Ubuntu: python3 aqi_health.py
# Dependencies: Python 3 standard library only. No internet required.

from math import exp

def gaussian(x, mean, sigma):
    return exp(-0.5 * ((x - mean) / sigma)**2)

# AQI: Good, Moderate, Poor, Severe; health-effect degrees.
aqi = 120
A = [gaussian(aqi, c, s) for c, s in [(40,30),(120,40),(200,50),(300,60)]]
B = [gaussian(aqi, c, s) for c, s in [(40,50),(150,60),(300,70)]]

print('AQI:', aqi)
print('AQI memberships (Good, Moderate, Poor, Severe):', [round(v,3) for v in A])
print('Health memberships (Healthy, Mild, Serious):', [round(v,3) for v in B])
print('Union Good/Moderate:', round(max(A[0],A[1]),3))
print('Intersection Good/Moderate:', round(min(A[0],A[1]),3))
print('Algebraic sum:', round(A[0]+A[1]-A[0]*A[1],3))
print('Algebraic product:', round(A[0]*A[1],3))
print('Bounded sum:', round(min(1,A[0]+A[1]),3))
print('Bounded difference:', round(max(0,A[0]-A[1]),3))

# Fuzzy Cartesian product and max-min/max-product composition.
C = [0.9, 0.6, 0.2]
R = [[min(a,b) for b in [0.9,0.6,0.2]] for a in [0.9,0.7,0.4,0.1]]
max_min = [max(min(C[j],R[i][j]) for j in range(3)) for i in range(4)]
max_product = [max(C[j]*R[i][j] for j in range(3)) for i in range(4)]
print('Cartesian product:')
for row in R: print(row)
print('Max-min composition:', [round(v,2) for v in max_min])
print('Max-product composition:', [round(v,2) for v in max_product])

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input (AQI example = 120).
# OUTPUT: AQI: 120
# OUTPUT: AQI memberships (Good, Moderate, Poor, Severe): [0.029, 1.0, 0.278, 0.011]
# OUTPUT: Health memberships (Healthy, Mild, Serious): [0.278, 0.882, 0.037]
# OUTPUT: Union Good/Moderate: 1.0
# OUTPUT: Intersection Good/Moderate: 0.029
# OUTPUT: Algebraic sum: 1.0
# OUTPUT: Algebraic product: 0.029
# OUTPUT: Bounded sum: 1
# OUTPUT: Bounded difference: 0
# OUTPUT: Cartesian product:
# OUTPUT: [0.9, 0.6, 0.2]
# OUTPUT: [0.7, 0.6, 0.2]
# OUTPUT: [0.4, 0.4, 0.2]
# OUTPUT: [0.1, 0.1, 0.1]
# OUTPUT: Max-min composition: [0.9, 0.7, 0.4, 0.1]
# OUTPUT: Max-product composition: [0.81, 0.63, 0.36, 0.09]
