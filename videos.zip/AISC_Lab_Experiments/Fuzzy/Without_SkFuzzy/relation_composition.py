# Max Min Max Product Composition
# Ubuntu: python3 relation_composition.py
# Dependencies: Python 3 standard library only (no internet needed).

R = [
    [0.6, 0.3],
    [0.2, 0.9]
]

S = [
    [1.0, 0.5, 0.3],
    [0.8, 0.4, 0.7]
]

# Max-Min Composition
max_min = []

for i in range(len(R)):
    row = []

    for j in range(len(S[0])):
        values = []

        for k in range(len(S)):
            values.append(min(R[i][k], S[k][j]))

        row.append(max(values))

    max_min.append(row)

# Max-Product Composition
max_product = []

for i in range(len(R)):
    row = []

    for j in range(len(S[0])):
        values = []

        for k in range(len(S)):
            values.append(R[i][k] * S[k][j])

        row.append(round(max(values), 2))

    max_product.append(row)

print("Max-Min Composition:")
for row in max_min:
    print(row)

print("Max-Product Composition:")
for row in max_product:
    print(row)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Max-Min Composition:
# OUTPUT: [0.6, 0.5, 0.3]
# OUTPUT: [0.8, 0.4, 0.7]
# OUTPUT: Max-Product Composition:
# OUTPUT: [0.6, 0.3, 0.21]
# OUTPUT: [0.72, 0.36, 0.63]
