# Room Temperature Controller - Pure Python
# Ubuntu: python3 room_temperature.py
# Dependencies: Python 3 standard library only (no internet needed).

# Mamdani fuzzy inference: triangular/shoulder memberships,
# MIN for AND/implication, MAX for aggregation, centroid defuzzification.
def membership(x, a, b, c):
    if a == b and x <= b: return 1.0
    if b == c and x >= b: return 1.0
    if x <= a or x >= c: return 0.0
    if x == b: return 1.0
    if x < b: return (x-a)/(b-a)
    return (c-x)/(c-b)

def degrees(x, lo, hi):
    mid = (lo+hi)/2
    return [membership(x,lo,lo,mid), membership(x,lo,mid,hi),
            membership(x,mid,hi,hi)]

def output_level(i,j):
    return max(0,min(2,1+j-i))

lo1,hi1 = 10,40
lo2,hi2 = 15,30
out_lo,out_hi = 0,100
x = float(input('current temperature (C): ') or '18')
y = float(input('target temperature (C): ') or '24')
if not (lo1 <= x <= hi1 and lo2 <= y <= hi2):
    raise ValueError('Inputs must be inside the indicated ranges.')
A = degrees(x,lo1,hi1)
B = degrees(y,lo2,hi2)
strength = [0.0,0.0,0.0]
for i in range(3):
    for j in range(3):
        k = output_level(i,j)
        strength[k] = max(strength[k], min(A[i],B[j]))

numerator = denominator = 0.0
for s in range(201):
    z = out_lo+(out_hi-out_lo)*s/200
    C = degrees(z,out_lo,out_hi)
    aggregated = max(min(strength[k],C[k]) for k in range(3))
    numerator += z*aggregated
    denominator += aggregated
result = numerator/denominator if denominator else (out_lo+out_hi)/2
print('heater power (%):',round(result,2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: 18
# INPUT: 24
# OUTPUT: current temperature (C): target temperature (C): heater power (%): 55.28
