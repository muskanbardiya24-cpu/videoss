# Fuzzy Sets for Noise Level
# Ubuntu: python3 noise_levels.py
# Dependencies: Python 3 standard library only (no internet needed).

from math import exp
# Gaussian membership for low and high noise, 0-100 dB.
def gaussian(x,mean,sigma):
    return exp(-0.5*((x-mean)/sigma)**2)

print('dB  Low    High   Union  Intersection')
for x in [0,20,40,60,80,100]:
    low = gaussian(x,20,10)
    high = gaussian(x,80,10)
    print(f'{x:>3} {low:.3f}  {high:.3f}  {max(low,high):.3f}   {min(low,high):.3f}')

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: dB  Low    High   Union  Intersection
# OUTPUT:   0 0.135  0.000  0.135   0.000
# OUTPUT:  20 1.000  0.000  1.000   0.000
# OUTPUT:  40 0.135  0.000  0.135   0.000
# OUTPUT:  60 0.000  0.135  0.135   0.000
# OUTPUT:  80 0.000  1.000  1.000   0.000
# OUTPUT: 100 0.000  0.135  0.135   0.000
