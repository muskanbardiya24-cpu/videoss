# ADALINE OR Gate
# Ubuntu: python3 or_gate.py
# Dependencies: Python 3 standard library only (no internet needed).

# OR GATE USING ADALINE LEARNING RULE
# This section follows the additional OR-gate calculation in the uploaded Excel workbook.

# Bipolar input patterns and target values
X = [
    [1, 1],
    [1, -1],
    [-1, 1],
    [-1, -1]
]
t = [1, 1, 1, -1]

# Initial values from the workbook
w1 = 0.1
w2 = 0.1
b = 0.1
alpha = 0.1

# The workbook displays two training epochs
epochs = 2

print("\nOR GATE USING ADALINE LEARNING RULE")
print("Epoch X1 X2 t Yin Error DeltaW1 DeltaW2 DeltaB NewW1 NewW2 NewB SquaredError")

for epoch in range(1, epochs + 1):
    for i in range(len(X)):
        x1, x2 = X[i]
        target = t[i]

        # ADALINE uses the continuous net input as its output
        yin = b + w1 * x1 + w2 * x2
        error = target - yin

        # Least Mean Squares (LMS) updates
        dw1 = alpha * error * x1
        dw2 = alpha * error * x2
        db = alpha * error

        w1 = w1 + dw1
        w2 = w2 + dw2
        b = b + db

        squared_error = error ** 2

        print(epoch, x1, x2, target,
              round(yin, 6), round(error, 6),
              round(dw1, 6), round(dw2, 6), round(db, 6),
              round(w1, 6), round(w2, 6), round(b, 6),
              round(squared_error, 8))

print("\nWeights after", epochs, "epochs")
print("W1 =", round(w1, 9))
print("W2 =", round(w2, 9))
print("Bias =", round(b, 9))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: OR GATE USING ADALINE LEARNING RULE
# OUTPUT: Epoch X1 X2 t Yin Error DeltaW1 DeltaW2 DeltaB NewW1 NewW2 NewB SquaredError
# OUTPUT: 1 1 1 1 0.3 0.7 0.07 0.07 0.07 0.17 0.17 0.17 0.49
# OUTPUT: 1 1 -1 1 0.17 0.83 0.083 -0.083 0.083 0.253 0.087 0.253 0.6889
# OUTPUT: 1 -1 1 1 0.087 0.913 -0.0913 0.0913 0.0913 0.1617 0.1783 0.3443 0.833569
# OUTPUT: 1 -1 -1 -1 0.0043 -1.0043 0.10043 0.10043 -0.10043 0.26213 0.27873 0.24387 1.00861849
# OUTPUT: 2 1 1 1 0.78473 0.21527 0.021527 0.021527 0.021527 0.283657 0.300257 0.265397 0.04634117
# OUTPUT: 2 1 -1 1 0.248797 0.751203 0.07512 -0.07512 0.07512 0.358777 0.225137 0.340517 0.56430595
# OUTPUT: 2 -1 1 1 0.206877 0.793123 -0.079312 0.079312 0.079312 0.279465 0.304449 0.41983 0.62904457
# OUTPUT: 2 -1 -1 -1 -0.164084 -0.835916 0.083592 0.083592 -0.083592 0.363057 0.388041 0.336238 0.69875494
# OUTPUT: 
# OUTPUT: Weights after 2 epochs
# OUTPUT: W1 = 0.363056533
# OUTPUT: W2 = 0.388040593
# OUTPUT: Bias = 0.336238067
