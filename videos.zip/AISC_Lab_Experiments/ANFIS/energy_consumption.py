# Energy Consumption Prediction
# Ubuntu: python3 energy_consumption.py
# Dependencies: Python 3 standard library only (no internet needed).

# First-order Sugeno ANFIS-style demonstration with 2 Gaussian membership
# functions (LOW and HIGH) per input; learn linear rule consequents by SGD.
# The dataset is generated synthetically for demonstration purposes only.
from itertools import product
from math import exp

names = ['temperature', 'humidity', 'appliances', 'hours']
ranges = [(20, 35), (40, 80), (1, 5), (1, 8)]
example = [30, 60, 3, 5]
scale = 15

def target(x):
    return 0.2*(x[0]-18)+0.03*(x[1]-30)+0.8*x[2]+0.5*x[3]

def gaussian(x, mean, sigma):
    return exp(-0.5*((x-mean)/sigma)**2)

def normalized(x):
    return [(v-lo)/(hi-lo) for v,(lo,hi) in zip(x,ranges)]

def rule_weights(x):
    # LOW/HIGH Gaussian MF of each input; 2**N rules.
    degrees=[]
    for v,(lo,hi) in zip(x,ranges):
        span=hi-lo
        degrees.append((gaussian(v,lo+0.25*span,span/3),
                        gaussian(v,lo+0.75*span,span/3)))
    fires=[]
    for choices in product([0,1],repeat=len(x)):
        weight=1.0
        for j,choice in enumerate(choices):
            weight*=degrees[j][choice]
        fires.append(weight)
    total=sum(fires)
    return [f/total for f in fires]

n=len(ranges)
num_rules=2**n
weights=[[0.0]*(n+1) for _ in range(num_rules)]

# Synthetic supervised training examples (three values for each feature).
levels=[[lo, (lo+hi)/2, hi] for lo,hi in ranges]
training=[]
for row in product(*levels):
    training.append((row,target(row)/scale))

for epoch in range(55):
    for raw,y in training:
        x=[1.0]+normalized(raw)
        firing=rule_weights(raw)
        estimated=sum(f*sum(a*b for a,b in zip(w,x))
                      for f,w in zip(firing,weights))
        error=y-estimated
        for j in range(num_rules):
            for k in range(n+1):
                weights[j][k]+=0.18*error*firing[j]*x[k]

print('Case:', 'Energy Consumption Prediction')
print('Membership functions/input: 2 (Gaussian)')
print('Number of fuzzy rules:', num_rules)
print('Enter inputs or press Enter to use example values:')
values=[]
for name,(lo,hi),default in zip(names,ranges,example):
    v=float(input(f'{name} ({lo}..{hi}) [{default}]: ') or default)
    if not lo <= v <= hi:
        raise ValueError(f'{name} must be between {lo} and {hi}')
    values.append(v)
x=[1.0]+normalized(values)
firing=rule_weights(values)
result=sum(f*sum(a*b for a,b in zip(w,x))
           for f,w in zip(firing,weights))*scale
print('synthetic energy (kWh):',round(result,2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: Press Enter for the displayed example values.
# OUTPUT: Case: Energy Consumption Prediction
# OUTPUT: Membership functions/input: 2 (Gaussian)
# OUTPUT: Number of fuzzy rules: 16
# OUTPUT: Enter inputs or press Enter to use example values:
# OUTPUT: temperature (20..35) [30]: humidity (40..80) [60]: appliances (1..5) [3]: hours (1..8) [5]: synthetic energy (kWh): 8.08
