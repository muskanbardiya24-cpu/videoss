# Crop Water Requirement
# Ubuntu: python3 crop_water_requirement.py
# Dependencies: Python 3 standard library only (no internet needed).

# First-order Sugeno ANFIS-style demonstration with 2 Gaussian membership
# functions (LOW and HIGH) per input; learn linear rule consequents by SGD.
# The dataset is generated synthetically for demonstration purposes only.
from itertools import product
from math import exp

names = ['soil moisture (%)', 'temperature (C)', 'humidity (%)']
ranges = [(20, 80), (15, 40), (30, 90)]
example = [35, 32, 45]
scale = 20

def target(x):
    return max(0.0, 0.15*(100-x[0]) + 0.14*(x[1]-20) + 0.06*(100-x[2]))

def gaussian(x, mean, sigma):
    return exp(-0.5*((x-mean)/sigma)**2)

def normalized(x):
    return [(v-lo)/(hi-lo) for v,(lo,hi) in zip(x,ranges)]

def rule_weights(x):
    # LOW/HIGH Gaussian MF of each input; 2**N rules.
    degrees=[]
    for v,(lo,hi) in zip(x,ranges):
        span=hi-lo
        degrees.append((gaussian(v,lo+0.25*span,span/3),
                        gaussian(v,lo+0.75*span,span/3)))
    fires=[]
    for choices in product([0,1],repeat=len(x)):
        weight=1.0
        for j,choice in enumerate(choices):
            weight*=degrees[j][choice]
        fires.append(weight)
    total=sum(fires)
    return [f/total for f in fires]

n=len(ranges)
num_rules=2**n
weights=[[0.0]*(n+1) for _ in range(num_rules)]

# Synthetic supervised training examples (three values for each feature).
levels=[[lo, (lo+hi)/2, hi] for lo,hi in ranges]
training=[]
for row in product(*levels):
    training.append((row,target(row)/scale))

for epoch in range(55):
    for raw,y in training:
        x=[1.0]+normalized(raw)
        firing=rule_weights(raw)
        estimated=sum(f*sum(a*b for a,b in zip(w,x))
                      for f,w in zip(firing,weights))
        error=y-estimated
        for j in range(num_rules):
            for k in range(n+1):
                weights[j][k]+=0.18*error*firing[j]*x[k]

print('Case:', 'Crop Water Requirement')
print('Membership functions/input: 2 (Gaussian)')
print('Number of fuzzy rules:', num_rules)
print('Enter inputs or press Enter to use example values:')
values=[]
for name,(lo,hi),default in zip(names,ranges,example):
    v=float(input(f'{name} ({lo}..{hi}) [{default}]: ') or default)
    if not lo <= v <= hi:
        raise ValueError(f'{name} must be between {lo} and {hi}')
    values.append(v)
x=[1.0]+normalized(values)
firing=rule_weights(values)
result=sum(f*sum(a*b for a,b in zip(w,x))
           for f,w in zip(firing,weights))*scale
print('water requirement (mm/day):',round(result,2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: Press Enter for the displayed example values.
# OUTPUT: Case: Crop Water Requirement
# OUTPUT: Membership functions/input: 2 (Gaussian)
# OUTPUT: Number of fuzzy rules: 8
# OUTPUT: Enter inputs or press Enter to use example values:
# OUTPUT: soil moisture (%) (20..80) [35]: temperature (C) (15..40) [32]: humidity (%) (30..90) [45]: water requirement (mm/day): 15.47
