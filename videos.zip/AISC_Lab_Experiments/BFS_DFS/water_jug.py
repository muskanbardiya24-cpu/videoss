# Water Jug - BFS and DFS
# Ubuntu: python3 water_jug.py
# Dependencies: Python 3 standard library only (no internet needed).

from collections import deque
from math import gcd

# BFS (shortest), DFS (any path) and Greedy Heuristic Search.
def next_states(state, c1, c2):
    a, b = state
    p = min(a, c2 - b)
    q = min(b, c1 - a)
    return list(dict.fromkeys([(c1,b),(a,c2),(0,b),(a,0),(a-p,b+p),(a+q,b-q)]))

def solve(c1, c2, target, method):
    start = (0, 0)
    frontier = deque([start]) if method == 'BFS' else [start]
    parent = {start: None}
    while frontier:
        if method == 'BFS':
            state = frontier.popleft()
        elif method == 'DFS':
            state = frontier.pop()
        else:
            # Greedy best-first: choose the jug state closest to the target.
            index = min(range(len(frontier)),
                        key=lambda i: min(abs(target-v) for v in frontier[i]))
            state = frontier.pop(index)
        if target in state:
            path = []
            while state is not None:
                path.append(state)
                state = parent[state]
            return path[::-1]
        for nxt in next_states(state, c1, c2):
            if nxt not in parent:
                parent[nxt] = state
                frontier.append(nxt)
    return None

c1 = int(input('Jug 1 capacity: '))
c2 = int(input('Jug 2 capacity: '))
target = int(input('Target amount: '))
if c1 <= 0 or c2 <= 0 or target < 0:
    print('Capacities must be positive and target non-negative.')
elif target > max(c1, c2) or target % gcd(c1, c2):
    print('No solution exists.')
else:
    for method in ['BFS','DFS','HEURISTIC']:
        path = solve(c1, c2, target, method)
        print(method + ':', ' -> '.join(map(str, path)) if path else 'No path')

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: 4
# INPUT: 3
# INPUT: 2
# OUTPUT: Jug 1 capacity: Jug 2 capacity: Target amount: BFS: (0, 0) -> (0, 3) -> (3, 0) -> (3, 3) -> (4, 2)
# OUTPUT: DFS: (0, 0) -> (0, 3) -> (3, 0) -> (3, 3) -> (4, 2)
# OUTPUT: HEURISTIC: (0, 0) -> (0, 3) -> (3, 0) -> (3, 3) -> (4, 2)
