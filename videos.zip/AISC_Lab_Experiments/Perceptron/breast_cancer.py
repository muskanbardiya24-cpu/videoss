# Breast Cancer Classification Using Perceptron (Wisconsin dataset)
# Ubuntu: python3 breast_cancer.py
# Needs scikit-learn and NumPy installed BEFORE working offline.
# Installation while connected to internet (Ubuntu virtual environment):
# sudo apt install python3-venv
# python3 -m venv ~/aisc-env
# source ~/aisc-env/bin/activate
# python3 -m pip install scikit-learn numpy
# Once installed, this program does NOT use the internet.

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score, confusion_matrix

X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

model = Perceptron(max_iter=1000, eta0=0.01, random_state=42)
model.fit(X_train, y_train)
pred = model.predict(X_test)

print('BREAST CANCER CLASSIFICATION - PERCEPTRON')
print('Samples:', len(X), '| Features:', X.shape[1])
print('Train:', len(X_train), '| Test:', len(X_test))
print('0 = Malignant, 1 = Benign')
print('Accuracy (%):', round(100 * accuracy_score(y_test, pred), 2))
print('Confusion matrix:')
for row in confusion_matrix(y_test, pred):
    print(row.tolist())

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed; Wisconsin dataset comes with scikit-learn.
# OUTPUT: BREAST CANCER CLASSIFICATION - PERCEPTRON
# OUTPUT: Samples: 569 | Features: 30
# OUTPUT: Train: 455 | Test: 114
# OUTPUT: 0 = Malignant, 1 = Benign
# OUTPUT: Accuracy (%): 96.49
# OUTPUT: Confusion matrix:
# OUTPUT: [41, 1]
# OUTPUT: [3, 69]
