# Discrete Hopfield Network Recall
# Ubuntu: python3 hopfield.py
# Dependencies: Python 3 standard library only (no internet needed).

# Discrete Hopfield: store and recall a bipolar pattern with Hebbian weights.
pattern = [1,1,1,-1]
noisy = [1,-1,1,-1]
n = len(pattern)
w = [[0 if i == j else pattern[i]*pattern[j] for j in range(n)]
     for i in range(n)]
state = noisy[:]
for _ in range(10):
    old = state[:]
    for i in range(n):
        net = sum(w[i][j]*state[j] for j in range(n))
        if net != 0: state[i] = 1 if net > 0 else -1
    if old == state: break
print('Stored:', pattern)
print('Noisy:', noisy)
print('Recalled:', state)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Stored: [1, 1, 1, -1]
# OUTPUT: Noisy: [1, -1, 1, -1]
# OUTPUT: Recalled: [1, 1, 1, -1]
